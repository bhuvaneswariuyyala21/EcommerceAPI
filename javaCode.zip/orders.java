package com.example.ecommerce.entity;

import javax.persistence.*;
import java.util.*;
import java.time.Instant;

@Entity
@Table(name="orders")
public class Order {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @ManyToOne private User user;
    @OneToMany(cascade=CascadeType.ALL) private List<OrderItem> items = new ArrayList<>();
    private Double total;
    private Instant timestamp = Instant.now();
    // getters/setters…
}
