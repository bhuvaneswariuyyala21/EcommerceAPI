package com.example.ecommerce.controller;

import com.example.ecommerce.entity.Product;
import com.example.ecommerce.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired private ProductService svc;

    @GetMapping
    public Page<Product> list(@RequestParam(defaultValue="0") int page,
                              @RequestParam(defaultValue="10") int size){
        return svc.listAll(PageRequest.of(page, size));
    }

    @GetMapping("/search")
    public Page<Product> search(@RequestParam String q,
                                @RequestParam(defaultValue="0") int page,
                                @RequestParam(defaultValue="10") int size){
        return svc.search(q, PageRequest.of(page, size));
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PostMapping public Product add(@RequestBody Product p){ return svc.add(p); }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PutMapping("/{id}") public Product update(@PathVariable Long id, @RequestBody Product p){
        return svc.update(id, p);
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ svc.delete(id); }
}
