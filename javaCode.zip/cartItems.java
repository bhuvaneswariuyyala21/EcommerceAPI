package com.example.ecommerce.entity;

import javax.persistence.*;

@Entity
public class CartItem {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @ManyToOne private User user;
    @ManyToOne private Product product;
    private int quantity;
    // getters/setters…
}
