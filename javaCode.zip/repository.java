package com.example.ecommerce.repository;

import com.example.ecommerce.entity.*;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface UserRepository extends JpaRepository<User,Long> {
    User findByUsername(String username);
}

public interface ProductRepository extends JpaRepository<Product,Long> {
    Page<Product> findByNameContainingIgnoreCaseOrCategoryContainingIgnoreCase(
        String name, String category, Pageable pageable);
}

public interface CartItemRepository extends JpaRepository<CartItem,Long> {
    List<CartItem> findByUser(User user);
    CartItem findByUserAndProduct(User user, Product product);
}

public interface OrderRepository extends JpaRepository<Order,Long> {
    List<Order> findByUser(User user);
}
