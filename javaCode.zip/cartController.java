package com.example.ecommerce.controller;

import com.example.ecommerce.entity.CartItem;
import com.example.ecommerce.dto.CartRequest;
import com.example.ecommerce.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
public class CartController {
    @Autowired private CartService svc;

    @GetMapping public List<CartItem> view(@AuthenticationPrincipal String username){
        return svc.list(username);
    }

    @PostMapping("/add")
    public CartItem add(@AuthenticationPrincipal String username, @RequestBody CartRequest req){
        return svc.add(username, req.getProductId(), req.getQuantity());
    }

    @PutMapping("/update")
    public void update(@AuthenticationPrincipal String username, @RequestBody CartRequest req){
        svc.update(username, req.getCartItemId(), req.getQuantity());
    }

    @DeleteMapping("/remove/{id}")
    public void remove(@PathVariable Long id){
        svc.remove(id);
    }
}
