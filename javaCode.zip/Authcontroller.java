package com.example.ecommerce.controller;

import com.example.ecommerce.config.JWTUtil;
import com.example.ecommerce.dto.*;
import com.example.ecommerce.entity.User;
import com.example.ecommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired private UserService userService;
    @Autowired private JWTUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody AuthRequest req){
        User u = userService.register(req.getUsername(), req.getPassword(), req.getRole());
        return ResponseEntity.ok("User registered: " + u.getUsername());
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest req){
        User u = userService.getUserRepository().findByUsername(req.getUsername());
        if (u == null || !new BCryptPasswordEncoder().matches(req.getPassword(), u.getPassword())) {
            return ResponseEntity.badRequest().body("Invalid credentials");
        }
        String token = jwtUtil.generateToken(u.getUsername(), u.getRole());
        return ResponseEntity.ok(new AuthResponse(token));
    }
}
